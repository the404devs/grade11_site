﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prjModularTest
{
    public partial class Form1 : Form
    {
        //variables-the random object is created only once
        //the random object variable r can be used in any function
        Random r = new Random();
        //These variables are used to maintain the game scores.
        int playerScore = 0;
        int computerScore = 0;
        //DO NOT create any other variable here
        //all necessary variables are to be made in the functions

        //Create all listed functions here






        public Form1()
        {
            InitializeComponent();
        }

    

        //******************************************
        //********DO NOT modify the following*******
        //******************************************
        private void btnPlay_Click(object sender, EventArgs e)
        {
            int card1 = 0;
            int card2 = 0;
            int card3 = 0;
            
            dealCardsToPlayer();
            dealCardsToComputer();

            card1 = Convert.ToInt16(lblCard1.Text);
            card2 = Convert.ToInt16(lblCard2.Text);
            card3 = Convert.ToInt16(lblCard3.Text);
            int player = playerTotal(card1,card2,card3);

            card1 = Convert.ToInt16(lblCard4.Text);
            card2 = Convert.ToInt16(lblCard5.Text);
            card3 = Convert.ToInt16(lblCard6.Text);
            int computer = computerTotal(card1,card2,card3);

            lblPlayerTotal.Text = player + "";
            lblComputerTotal.Text = computer + "";

            if (player > computer)
            {
                updatePlayerScore();
            }
            else if (player < computer)
            {
                updateComputerScore();
            }
            else
            {
                updateTies();
            }

        }
    }
}
