﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prjArrayTest
{
    public partial class Form1 : Form
    {
        /***************DO NOT TOUCH ANY CODE ALREADY WRITTEN. SIMPLY ADD YOUR OWN TO
         * SUCCESSFULLY FILL THE LABELS IN THE FORM WITH THE ANSWERS.*********************/

        StreamReader sw;
        string[] words;//WORDS IS REQUIRED TO SOLVE THE WORS ARRAY PROBLEMS
        int[] numbers;//NUMBERS IS REQUIRED TO SOLVE THE NUMBERS ARRAYS PROBLEMS
        String _temp;

        public Form1()
        {
            InitializeComponent();
             String[] delimiterChars = { "\r","\r\n","\t"};
             sw= new StreamReader("words.txt");
             words = sw.ReadToEnd().Split(delimiterChars, StringSplitOptions.None);
             sw.Close();
             for (int x = 0; x < words.Length; x++)
             {
                 _temp = words[x];
                 words[x] = _temp.Trim();
             }
             sw = new StreamReader("numbers.txt");
             String[] temp = sw.ReadToEnd().Split(delimiterChars, StringSplitOptions.None);
             sw.Close();
             numbers = new int[temp.Length];
             for (int x = 0; x < temp.Length; x++)
             {
                 numbers[x]=Convert.ToInt16 (temp[x]);

             }
             lblStatus.Text = "All words and numbers are loaded into the array. Processing may commence.";
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
           
        }

    }
}


