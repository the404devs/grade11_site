﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjBubbleSort
{
    public partial class Form1 : Form
    {
        int[] data = new int[10];
        Random r = new Random();

      

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreateAndDisplay_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSortAndDisplay_Click(object sender, EventArgs e)
        {
           
        }


      

        private void btnTestSortFunction_Click(object sender, EventArgs e)
        {
           
        }

      

       
    }
}
