﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjMyFirstProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /*We are now in the code window of the Visual Stuido IDE. IDE stands for Integrated Development Environment. 
         * This means all the parts I need to program are integrated into one place. The VS IDE is made up of several important parts. 
         * These include the Designer, Toolbox, Solutions Explorer, and Proporties Window.*/
          private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show ("Error: Windows.exe has stopped responding.");
        }
    }
}
