﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjLesson2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDontClick_Click(object sender, EventArgs e)
        {
            MessageBox.Show("NEVER GONNA GIVE YOU UP");
            MessageBox.Show("NEVER GONNA LET YOU DOWN");
            MessageBox.Show("NEVER GONNA RUNA ROUND AND DESERT YOU");
        }

        private void txtText_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("NEVER GONNA GIVE YOU UP");
            MessageBox.Show("NEVER GONNA LET YOU DOWN");
            MessageBox.Show("NEVER GONNA RUNA ROUND AND DESERT YOU");
        }

        private void lblClick_MouseHover(object sender, EventArgs e)
        {
            MessageBox.Show("GO AWAY!");
        }

    }
}
